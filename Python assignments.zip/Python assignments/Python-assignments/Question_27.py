#Write a Python program to implement multiplication table
n = int(input("Enter n: "))

for i in range (1, 11):
    print(i*n)

"""output:
Enter n: 5
5
10
15
20
25
30
35
40
45
50"""