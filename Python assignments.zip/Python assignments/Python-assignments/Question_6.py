# Write a program in Python to convert any temperature from Celcius to Fahrenheit.

c = float(input("Temp in celsius:"))
f = (c * 9/5) +32
print("Temp in fahrenheit is:", f)

""" output:
Temp in celsius:32.5
Temp in fahrenheit is:90.5"""