#Write a program in Python to find the volume of a sphere with radius 6cm

import math

r = 6
volume = (4/3) * math.pi * (r ** 3)
print("The volume of the sphere is in cubic centimeteres: ", volume)