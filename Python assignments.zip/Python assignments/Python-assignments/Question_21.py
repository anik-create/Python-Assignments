#Write a program in Python to print Reverse of a Number
num = int(input("Enter a +ve integer: "))
rev_num = str(num)[::-1]

print("The reversed number is:", rev_num)

"""output:
Enter a +ve integer: 483
The reversed number is: 384"""