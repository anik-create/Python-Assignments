# Write a program in Python to find given no is Even or Odd.
num = int(input("Enter the number: "))

if(num % 2 == 0):
    print("The number is even")
else:
    print("The number is odd")    

    """output:
    Enter the number: 45
    The number is odd
    """